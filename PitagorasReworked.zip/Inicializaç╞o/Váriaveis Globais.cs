﻿namespace PitagorasReworked
{
    public static class VariaveisGlobais
    {
        //Área calculo
        public const double Pi = 3.1416;
        public const double VelocidadeSomMS = 340.29;
        public const double Const17 = 17.67;
        public const double Const243 = 243.5;
        public const double EulerCalculado122 = 16.6413213538;
        public const double EulerCalculado112 = 16.6141385355;
        public const double ConstanteTetens = 6.1078;

    }
}