﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PitagorasReworked
{
    class Principal
    {
        static void Main(string[] args)
        {
            Menus_Splash.Splash();
            Script_Menu.Principal();
        }
    }
}
