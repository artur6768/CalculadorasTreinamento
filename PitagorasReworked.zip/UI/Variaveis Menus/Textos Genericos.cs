﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PitagorasReworked
{
    public static class TextosGenericos
    {
        public const string BarraMenus = "==========================================";
        public const string InsValo = "Por favor insira o seguinte valor:";
        public const string InsTemp = "Temperatura em °C:";
        public const string InsTempK = "Temperatura em K:";
        public const string InsPres = "Pressão em hPa:";
        public const string SuaEsch = "Sua escolha: ";
    }
}
