﻿using PitagorasReworked.UI.Erros;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PitagorasReworked
{
    public static class Menus_Principal
    {
        public static string MenuPrincipal = $"{TextosGenericos.BarraMenus}\n" +
                                   "Qual calculadora deseja utiizar?\n" +
                                           "[1] Pitagoras\n" +
                                      "[2] Volume da esfera\n" +
                                          "[3] Area do circulo\n" +
                                      "[4] Comprimento do circulo\n" +
                                        "[5] Calcular meia-vida \n" +
                                        "[7] Conversor distância ETS2\n" +
                                        "[8] Calculadoras METEO\n" +
                              $"{TextosGenericos.BarraMenus}";
    }           
}
